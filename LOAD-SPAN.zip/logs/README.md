# Logs Directory

This directory contains runtime logs for LOAD-SPAN.

Log files:
- `load_span.log` - Main application log
- `anomaly.log` - Anomaly detection events
- `errors.log` - Error and exception logs

Log rotation is configured for 30 days retention.

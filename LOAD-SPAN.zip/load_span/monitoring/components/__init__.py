"""Dashboard UI components."""
